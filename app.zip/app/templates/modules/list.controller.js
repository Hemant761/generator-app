(function(){
'use strict';

angular.module("<%= ngAppName %>").controller("<%= ngModuleName %>ListController",function([],{}){

});

})()