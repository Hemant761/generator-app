(function(){
'use strict';

angular.module("<%= ngAppName %>").controller("new<%= ngModuleName %>Controller",function([],{}){

});

})()