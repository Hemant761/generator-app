(function(){
'use strict';

angular.module("<%= ngAppName %>").controller("<%= ngModuleName %>Service",function([],{}){

});

})()