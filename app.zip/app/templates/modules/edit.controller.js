(function(){
'use strict';

angular.module("<%= ngAppName %>").controller("edit<%= ngModuleName %>Controller",function([],{}){

});

})()